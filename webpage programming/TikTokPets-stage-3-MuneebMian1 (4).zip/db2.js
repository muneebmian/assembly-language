'use strict'

// database operations.
// Async operations can always fail, so these are all wrapped in try-catch blocks
// so that they will always return something
// that the calling function can use. 

// Export functions that will be used in other files.
module.exports = {
  dumpTable: dumpTable
}

// using a Promises-wrapped version of sqlite3
const db = require('./sqlWrap');

const dumpTableCmd = "SELECT * FROM PrefTable";

async function dumpTable() {
  try {
    let results = await db.all(dumpTableCmd, []);
    return results;
  } catch (error) {
    console.log("error", error);
    return [];
  }
}
