
let videoElmts = document.getElementsByClassName("tiktokDiv");

let reloadButtons = document.getElementsByClassName("reload");
let heartButtons = document.querySelectorAll("div.heart");

const saved0 = document.getElementById("loved0");
const saved1 = document.getElementById("loved1");
const savedunlove = document.getElementById("unloved0");
const savedunlove1 = document.getElementById("unloved1");
const element = document.getElementById("loved0");
element.remove(); 
const element1 = document.getElementById("loved1");
element1.remove(); 


let dataid = [0,0];
var urls = [,];
videos1id = 0;
videos2id = 0;

for (let i=0; i<2; i++) {
  let reload = reloadButtons[i]; 
  reload.addEventListener("click",function() { reloadVideo(videoElmts[i]) });
  

 heartButtons[i].addEventListener("click",function() {  
   
   //next 4 lines replace unfilled w/filled
   const element11 = 
   document.getElementById("unloved"+i);
   element11.remove(); 
    //if firt i clicked remove heart from second and add a unfilled
   if(i==0)                                             {
      dataid = [videos1id,videos2id];
document.getElementById("idname"+i).appendChild(saved0);
    element1.remove(); 
     
      } 
  else if(i==1)                                          {
    data = [videos2id,videos1id];
   savedunlove1.remove(); document.getElementById("idname1").appendChild(saved1);
  element.remove(); 
document.getElementById("idname0").appendChild(savedunlove);   
  }  
 
 });
       
}



// function getrandomVideo()
// {
 sendGetRequest("./getTwoVideos")
.then(function(data) {
console.log("got back the random videos:"); //remember 
urls = [data[0],data[1]];
videos1id = data[2];
videos2id = data[3];
dataid = [videos1id,videos2id];


for (let i=0; i<2; i++) {
      addVideo(urls[i],videoElmts[i]);
    }
    // load the videos after the names are pasted in! 
    loadTheVideos();
});


 let nextButton = document.getElementsByClassName("enabledButton")[0]; 


nextButton.addEventListener('click' , function(){
   sendPostRequest("/insertPref", dataid)
   .then(function(data) {
     if(data=="pick winner")
     {   
       console.log("pickwinner")
       location.replace("./winner.html")
     }
    else{
      
      sendGetRequest("./getTwoVideos")
      .then(function(data) {
      console.log("got back the random videos:"); 
      urls = [data[0],data[1]];
      console.log(urls);
      videos1id = data[2];
      videos2id = data[3];
      dataid = [videos1id,videos2id];
      location.reload();
       for (let i=0; i<2; i++) {

       addVideo(urls[i],videoElmts[i]);
        }
    // load the videos after the names are pasted in! 
        loadTheVideos();
});
      
    }
   });
 });
   
   