'use strict'

async function sendPostRequest1(url,Usrname,tikurl,Nickname) {
  let data1 = Usrname+ ',' + tikurl + ',' + Nickname;
  console.log("about to send post request");
  let response = await fetch(url, {
    method: 'POST', 
    headers: {'Content-Type': 'text/plain'},
    body: data1 });
  if (response.ok) {
    let data1 = await response.text();
    return data1;
  } else {
    throw Error(response.status);
  }
}
let redButton = document.getElementById("redButton");
 redButton.onclick = function() {
  var videoName = document.getElementById("VideoNickname").value;
  var userName = document.getElementById("Username").value;
   var vidUrl = document.getElementById("TiktokUrl").value;
   sendPostRequest1('/newlog', userName, vidUrl, videoName)
   .then(function (data) {
    console.log("the data that we got is" + data);
    console.log("got POST");
    sessionStorage.setItem("VideoNickname", videoName);
    window.location.href = "/newpage.html";
    
    
  })
   .catch(function (error) {
     console.error('Error:', error);
  });
 }
   /*
   sessionStorage.setItem("VideoNickname",VideoNickname);
   location.replace("./newpage.html");
   
   let Nickname = 
    sessionStorage.getItem("VideoNickname");
    document.getElementById("input5").innerHTML = 
    Nickname;
*/
   



