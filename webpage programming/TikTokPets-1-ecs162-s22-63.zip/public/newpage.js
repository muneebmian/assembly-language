'use strict'
let redButton2 = document.getElementById("secondButton");
let userInput = sessionStorage.getItem("VideoNickname");
let videoNameDisplay = document.getElementById("input5");
videoNameDisplay.textContent = userInput;
secondButton.onclick = function() {
  window.location.href = "tiktokpets.html";
}