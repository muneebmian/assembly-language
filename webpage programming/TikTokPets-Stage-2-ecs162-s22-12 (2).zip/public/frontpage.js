'use strict'

// this needs to be made into json
async function sendPostRequest1(url,Usrname,tikurl,Nickname) {
  //let data1 = Usrname+ ',' + tikurl + ',' + Nickname
  let data1 = { //data in json form 
    "userid" : Usrname,
    "url" : tikurl,
    "nickname" : Nickname
  };
  let data2 = JSON.stringify(data1);
  console.log(data2);
  console.log("about to send post request");
  let response = await fetch(url, {
    method: 'POST', 
    headers: {'Content-Type': 'application/json'},
    body: data2 });
  if (response.ok) {
    let data1 = await response.text();
    return data1;
  } else {
    throw Error(response.status);
  }
}

let redButton = document.getElementById("redButton"); // continue button on page 1
 redButton.onclick = function() {
  var videoName = document.getElementById("VideoNickname").value;
  var userName = document.getElementById("Username").value;
   var vidUrl = document.getElementById("TiktokUrl").value;
   sendPostRequest1('/videodata', userName, vidUrl, videoName)
   .then(function (data) {
    console.log("the data that we got is" + data);
    console.log("got POST"); 
    
     if(data.length == 0) // went over the limit
     {
       alert ("you are going over the video limits")
       
     }
    // in either cases, we jump to videoPreview 
    window.location.href = "./videoPreview.html";
     
  })
   .catch(function (error) {
     console.error('Error:', error);
  });
 }
let redButtontop = document.getElementById("redButtontop");
 redButtontop.onclick = function() {
    window.location.href = "myvideos.html";
  }

  
   


