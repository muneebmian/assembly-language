'use strict'
// hahaha my dev master will kill me
let video1 = document.getElementById("video1");
let video2 = document.getElementById("video2");
let video3 = document.getElementById("Video3");
let video4 = document.getElementById("Video4");
let video5 = document.getElementById("Video5");
let video6 = document.getElementById("Video6");
let video7 = document.getElementById("Video7");
let video8 = document.getElementById("Video8");
let videoInputs = [video1, video2, video3, video4, video5, video6, video7, video8];
let delete1 = document.getElementById("delete1");
let delete2 = document.getElementById("delete2");
let delete3 = document.getElementById("delete3");
let delete4 = document.getElementById("delete4");
let delete5 = document.getElementById("delete5");
let delete6 = document.getElementById("delete6");
let delete7 = document.getElementById("delete7");
let delete8 = document.getElementById("delete8");
let deleteButtons = [delete1,delete2,delete3,delete4,delete5,delete6,delete7,delete8];
async function setUpDeleteButtons()
{
    console.log("setting up delete buttons")
    for( let i = 0 ; i < 8; i ++)
      {
        deleteButtons[i].addEventListener("click", async function(){
          console.log("button" + (i+1) + "is clicked");
          await sendDeleteRequest(videoInputs[i].value);
          
        })
      }
}
let addButton = document.getElementById("addnewtop");
addButton.addEventListener("click", function(){
  window.location.href = "/tiktokpets.html"
})
setUpDeleteButtons();
// given a video to delete, its name in text, delete the video from the data base and display this page again
async function sendDeleteRequest(videoName)
  {
    console.log("about to send delete request");
    let response = await fetch('/deletevideo', {
      method: 'POST',
      headers:{'Content-Type': 'text/plain'},
      body : videoName});
    if(response.ok) {
      let data1 = await response.text();
      // display the whole thing again
      //handleVideosDisplay(JSON.parse(data1));
      window.location.reload();
    }
    else {
      throw Error(response.status);
    }
  }
async function GetAllVideos(url)
{
    let response = await fetch(url);
    if(response.ok) {
      let data = await response.text();
      return data;
    }
    else {
      throw Error(response.status);
    }
}
GetAllVideos('/getList')
.then(function(data) {
  console.log("got back all videos:", data);
  let dataJson = JSON.parse(data);
  console.log (dataJson.length);
  handleVideosDisplay(dataJson);
})
.catch(function(error) {
  console.error('Error:', error);
});  
//display the video names
function handleVideosDisplay(dataJson)
{
    for(var i = 0 ; i < 8; i++)
  {
    if(i > dataJson.length - 1)
    {
      break;
    }
    var obj = dataJson[i]; // singular json
    console.log(obj["nickname"]);
    videoInputs[i].value = obj["nickname"]; 
  }
  if(dataJson.length < 8) // dont have 8 videos
  {
    console.log("less length reached");
    // gray out play game button
    let bottomButton = document.getElementById("playgame");
    bottomButton.style.backgroundColor = "rgb(246,142,166)";
  }
  else{ // have 8 videos
    // gray out add new button
    console.log("max length reached")
    
    let topButton = document.getElementById("addnewtop");
    topButton.style.backgroundColor = "rgb(246,142,166)";
  }
}
/*
let input1 = document.getElementById("input1");
 input1.onclick = function() {
  let vidObj = input1;
  insertVideo(vidObj)
    .then(function() {
      console.log("success!");
    })
    .catch(function(err) {
      console.log("SQL error",err)} );
    
  }
*/
/*
 delete1.onclick = function() {
    /*console.log("deleted1");
    let input2 = document.getElementById("input2");
    input1=input2;
    console.log("deleted1");*/

  