// index.js
// This is our main server file

// include express
const express = require("express");
// create object to interface with express
const fetch = require("cross-fetch");
// get Promise-based interface to sqlite3
const db = require('./sqlWrap');
// this also sets up the database
const app = express();
//middleware
app.use(express.text());
app.use(express.json());
app.use(express.urlencoded());  
// Code in this section sets up an express pipeline

// print info about incoming HTTP request 
// for debugging
app.use(function(req, res, next) {
  console.log(req.method,req.url);
  next();
})

// make all the files in 'public' available 
app.use(express.static("public"));
// if no file specified, return the main page
app.get("/", (request, response) => {
  response.sendFile(__dirname + "/public/tiktokpets.html");
});
app.get('/getMostRecent', async (request, response) => {
  console.log("getting most recent video")
  // manually get the most recent video
  //let result = await getVideo(previousVideo.nickname);
  let wholeDb = await dumpTable();
  console.log("whole table: \n", JSON.stringify(wholeDb));
  let res = await getmostRecentVid();
  // get the most recent video, just need to find the one where flag = 1 
  response.json(res);
}
);
app.get('/getList', async(request, response) => {
  console.log("getting all videos in a list")
  let res = await dumpVideos();
  response.json(res);
});
// will send a json of the video name
app.post('/deletevideo', async function(req,res,next) {
  console.log("Server received a post request for deleting", req.body);
  await deleteVideo(req.body);
  let remainingVideos = dumpVideos();
  res.json(remainingVideos);
}
)
app.post('/videodata', async function(req, res, next) {
  console.log("Server received a post request at", req.url);
  let allVideos = await dumpTable() // get the current # of videos
  let videosCount = allVideos.length;
  console.log("we have this amount of videos:", videosCount);
  if(videosCount <= 7)
  {
    let input = req.body; // input is in json
  console.log("the input json is", JSON.stringify(input));
  await insertVideo(input); // insert the video and change flag
  let dbLastElem = await getVideo(input.nickname);
  res.json(dbLastElem);  
  }
  else{ // over video limit, return empty 
    console.log("over the vid limit, sending empty");
    res.send(null);
  }
  
});
// Need to add response if page not found!
app.use(function(req, res)
  { res.status(404); res.type('txt'); res.send('404 - File '+req.url+' not found'); });
 // Server Receives and responds
// end of pipeline specification

// Now listen for HTTP requests
// it's an event listener on the server!
const listener = app.listen(3000, function () {
  console.log("The static server is listening on port " + listener.address().port);
});
async function ChangeFlags(vNickName)
{
  console.log("attempting to change flags")
  var update = "UPDATE VideoTable SET flag = 0 WHERE flag = 1";
  db.run(update);
  let wholeDb = await dumpTable();
  console.log("whole table again: \n", JSON.stringify(wholeDb));
  console.log("changing flags complete")
}
async function insertVideo(v) {
  let allVideos = await dumpTable() // get the current # of videos
  let videosCount = allVideos.length;
  // set previous video flag to false
  if(videosCount != 0) // there is a recent video
  {
    let previousVideo = await getmostRecentVid();
    console.log("attempting to change flags of:", JSON.stringify(previousVideo))
    console.log("Sending into the changeflags function:", previousVideo.nickname)
   await ChangeFlags(previousVideo.nickname); 
    
  }
  // set previous video to false, if it exists
  const sql = "insert into VideoTable (url,nickname,userid,flag) values (?,?,?,TRUE)";

  await db.run(sql,[v.url, v.nickname, v.userid]);
  console.log("insertion step complete")
  
  
}

async function getmostRecentVid() {
  const sql = 'select * from VideoTable where flag = ?'
  let result = await db.get(sql, 1);
  return result;
}
async function deleteVideo(nickname) {
  console.log("deleting video", nickname);
  const sql = 'delete from VideoTable where nickname = ?';
  await db.run(sql,[nickname]);
}
// an async function to get a video's database row by its nickname
async function getVideo(nickname) {

  // warning! You can only use ? to replace table data, not table name or column name.
  const sql = 'select * from VideoTable where nickname = ?';

let result = await db.get(sql, [nickname]);
return result;
}

// get all videos from the database 
async function dumpVideos() {
  const sql = "select nickname from VideoTable"
  let result = await db.all(sql)
  return result;
}
// an async function to get the whole contents of the database 
async function dumpTable() {
  const sql = "select * from VideoTable"
  
  let result = await db.all(sql)
  return result;
}